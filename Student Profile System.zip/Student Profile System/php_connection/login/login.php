<!DOCTYPE html>
<html lang="en">
}
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
</head>
<style>
    body 
    {
        background-image: url("paper.gif");
        background-color: #cccccc;
    }
</style>
<body>

	<div class="container" style="color:green">
     <h1>                                           WelCome In Studen Profile</h1>
    </div>
<?php
$connect=mysqli_connect("localhost","root","","php_connection") or die("Connection Faild");
if(!empty($_POST['save']))
{
    $username=$_POST['un'];
    $password=$_POST['pw'];
    $query="select * from login where username='$username' and password='$password'";
    $result=mysqli_query($connect,$query);
    $count=mysqli_num_rows($result);
    if($count>0)
    {
        // echo "Login Succesful ";
        header("location: http://localhost/php_connection/index_page");  
    
    }
    else
    {
        echo "Login Failed";
    }
}
?>
<form method="post" bg_color="red">
    Enter Username <input type="text" name="un"/>
<br/>
Enter Password <input type="password" name="pw" />
<br/>
<input type="submit" name="save" value="Login" />
</form>
</body>
</html>